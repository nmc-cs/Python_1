
print('Nitin M Chava')
print('I am a sophomore at the University of Missouri.')
print("I like to stay fit by playing tennis,lifting,running.")
print("Recently, I completed my AWS Cloud Practitioner Certification.")
